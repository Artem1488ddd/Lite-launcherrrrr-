package com.lite.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

private sealed class S
private class Sec(val t: String) : S()
private class Sw(val k: String, val t: String) : S()
private class Ch(val k: String, val t: String, val l: List<String>, val v: List<String>) : S()
private class Num(val k: String, val t: String, val min: Int, val max: Int, val u: String = "") : S()
private class Col(val k: String, val t: String) : S()
private class Act(val t: String, val r: () -> Unit) : S()

class SettingsActivity : Activity() {
    private lateinit var box: LinearLayout
    private var fg = 0
    private val reqExport = 11
    private val reqImport = 12

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        P.init(this)
        Apps.loadCache(this)
        fg = Th.text(this)
        val sv = ScrollView(this)
        sv.setBackgroundColor(Th.bg(this))
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        sv.addView(box)
        setContentView(sv)
        for (s in list()) add(s)
    }

    // ───────────────────────── список настроек ─────────────────────────

    private fun list(): List<S> {
        val gest = listOf("Ничего", "Меню приложений", "Шторка уведомлений", "Настройки лаунчера", "Фонарик", "На первый стол", "Меню рабочего стола")
        val gestV = listOf("none", "drawer", "notif", "settings", "torch", "first", "menu")
        val l = ArrayList<S>()
        l.add(Sec("Производительность"))
        l.add(Sw("lite", "Режим экономии: без анимаций, теней и прозрачности"))
        l.add(Sw("animAuto", "Отключать анимации при низком заряде / экономии батареи"))

        l.add(Sec("Рабочий стол"))
        l.add(Num("cols", "Колонок в сетке", 3, 6))
        l.add(Num("rows", "Строк в сетке", 3, 8))
        l.add(Num("pages", "Количество рабочих столов", 1, 9))
        l.add(Sw("infinite", "Бесконечная прокрутка столов"))
        l.add(Sw("lock", "Заблокировать расположение иконок"))
        l.add(Sw("align", "Автовыравнивание иконок"))
        l.add(Num("edge", "Отступы по краям", 0, 32, " dp"))
        l.add(Num("gap", "Отступ вокруг иконки", 0, 16, " dp"))
        l.add(Sw("dots", "Индикатор страниц"))
        l.add(Num("dotSize", "Размер индикатора страниц", 4, 14, " dp"))
        l.add(Sw("clock", "Виджет часов"))
        l.add(Sw("date", "Дата под часами"))
        l.add(Num("clockSp", "Размер шрифта часов", 24, 80, " sp"))

        l.add(Sec("Иконки"))
        l.add(Num("iconDp", "Размер иконок на столе", 32, 64, " dp"))
        l.add(Num("labelSp", "Размер подписей", 8, 16, " sp"))
        l.add(Sw("showLabels", "Подписи на рабочем столе"))
        l.add(Num("lines", "Строк в подписи", 1, 2))
        l.add(Sw("shadow", "Тень подписей"))
        l.add(Ch("homeText", "Цвет подписей", listOf("Белый", "Чёрный"), listOf("white", "black")))
        l.add(Ch("shape", "Форма иконок", listOf("Круг", "Сквиркл", "Скруглённый квадрат", "Квадрат"), listOf("circle", "squircle", "round", "square")))
        l.add(Sw("mono", "Монохромные иконки"))
        l.add(Num("scale", "Общий масштаб интерфейса", 70, 130, " %"))

        l.add(Sec("Док"))
        l.add(Sw("dockShow", "Показывать док"))
        l.add(Num("dockN", "Иконок в доке", 3, 6))
        l.add(Num("dockIcon", "Размер иконок в доке", 32, 64, " dp"))
        l.add(Sw("dockLabels", "Подписи в доке"))
        l.add(Num("dockAlpha", "Непрозрачность дока", 0, 100, " %"))
        l.add(Num("dockRadius", "Скругление дока", 0, 40, " dp"))
        l.add(Num("dockMargin", "Отступ дока от краёв", 0, 32, " dp"))

        l.add(Sec("Меню приложений"))
        l.add(Num("dCols", "Колонок", 3, 6))
        l.add(Sw("dList", "Список вместо сетки"))
        l.add(Num("dIcon", "Размер иконок в меню", 28, 64, " dp"))
        l.add(Ch("dSort", "Сортировка", listOf("По алфавиту", "По частоте запуска", "Недавние сверху"), listOf("alpha", "freq", "recent")))
        l.add(Ch("search", "Строка поиска", listOf("Сверху", "Снизу", "Убрать"), listOf("top", "bottom", "off")))
        l.add(Sw("autoKb", "Открывать клавиатуру вместе с меню"))
        l.add(Num("dAlpha", "Непрозрачность фона меню", 0, 100, " %"))
        l.add(Act("Скрытые приложения") { hiddenDialog() })

        l.add(Sec("Внешний вид"))
        l.add(Ch("theme", "Тема", listOf("Как в системе", "Светлая", "Тёмная", "По времени (7–19 светлая)"), listOf("system", "light", "dark", "time")))
        l.add(Col("accent", "Акцентный цвет"))
        if (Build.VERSION.SDK_INT >= 27) l.add(Sw("accWall", "Акцент из цветов обоев"))
        l.add(Sw("hideStatus", "Скрыть строку состояния"))
        l.add(Sw("hideNav", "Скрыть навигационную панель"))
        l.add(Act("Сменить обои") {
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои"))
            } catch (_: Exception) {
            }
        })

        l.add(Sec("Анимации"))
        l.add(Sw("anim", "Анимации включены"))
        l.add(Ch("animType", "Открытие меню приложений", listOf("Слайд", "Затухание", "Увеличение"), listOf("slide", "fade", "zoom")))
        l.add(Ch("pageFx", "Смена рабочих столов", listOf("Слайд", "Затухание", "Увеличение"), listOf("slide", "fade", "zoom")))
        l.add(Ch("launchAnim", "Запуск приложений", listOf("Из иконки", "Затухание", "Слайд", "Без эффекта"), listOf("zoom", "fade", "slide", "none")))
        l.add(Num("animMs", "Длительность анимаций", 80, 600, " мс"))

        l.add(Sec("Жесты"))
        l.add(Ch("gUp", "Свайп вверх", gest, gestV))
        l.add(Ch("gDown", "Свайп вниз", gest, gestV))
        l.add(Ch("gDouble", "Двойной тап", gest, gestV))
        l.add(Ch("gLong", "Долгое нажатие на пустое место", gest, gestV))
        l.add(Ch("gHome", "Кнопка «Домой»", listOf("Закрыть меню и на первый стол", "Открыть меню приложений", "Ничего"), listOf("reset", "drawer", "none")))

        l.add(Sec("Сервис"))
        l.add(Act("Сделать лаунчером по умолчанию") {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (_: Exception) {
                toast("Нажмите «Домой» и выберите Lite Launcher")
            }
        })
        l.add(Act("Резервная копия: сохранить в файл") {
            startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json").putExtra(Intent.EXTRA_TITLE, "litelauncher-backup.json"), reqExport
            )
        })
        l.add(Act("Восстановить из файла (включая раскладку стола)") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), reqImport
            )
        })
        l.add(Act("Сбросить настройки лаунчера") {
            AlertDialog.Builder(this).setTitle("Сбросить всё?")
                .setMessage("Настройки, раскладка стола и дока будут удалены.")
                .setPositiveButton("Сбросить") { _, _ ->
                    P.reset()
                    recreate()
                }
                .setNegativeButton("Отмена", null).show()
        })
        return l
    }

    // ───────────────────────── отрисовка строк ─────────────────────────

    private fun tv(t: String, sp: Float, c: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        v.setTextColor(c)
        return v
    }

    private fun twoLine(title: String): Pair<LinearLayout, TextView> {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dp(16), dp(12), dp(16), dp(12))
        r.addView(tv(title, 16f, fg))
        val sub = tv("", 13f, Th.withAlpha(fg, 60))
        r.addView(sub)
        return Pair(r, sub)
    }

    private fun add(s: S) {
        when (s) {
            is Sec -> {
                val t = tv(s.t.uppercase(), 13f, Th.accent(this))
                t.typeface = Typeface.DEFAULT_BOLD
                t.setPadding(dp(16), dp(22), dp(16), dp(6))
                box.addView(t)
            }
            is Sw -> {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                r.gravity = Gravity.CENTER_VERTICAL
                r.setPadding(dp(16), dp(12), dp(16), dp(12))
                val sw = Switch(this)
                sw.isChecked = P.b(s.k)
                sw.setOnCheckedChangeListener { _, c -> P.put(s.k, c) }
                r.addView(tv(s.t, 16f, fg), LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(sw)
                r.setOnClickListener { sw.toggle() }
                box.addView(r)
            }
            is Ch -> {
                val (r, sub) = twoLine(s.t)
                fun cur(): String = s.l.getOrElse(s.v.indexOf(P.s(s.k))) { "" }
                sub.text = cur()
                r.setOnClickListener {
                    AlertDialog.Builder(this).setTitle(s.t)
                        .setSingleChoiceItems(s.l.toTypedArray(), s.v.indexOf(P.s(s.k))) { d, w ->
                            P.put(s.k, s.v[w])
                            sub.text = cur()
                            d.dismiss()
                        }.show()
                }
                box.addView(r)
            }
            is Num -> {
                val (r, sub) = twoLine(s.t)
                sub.text = "${P.i(s.k)}${s.u}"
                r.setOnClickListener {
                    val lin = LinearLayout(this)
                    lin.orientation = LinearLayout.VERTICAL
                    lin.setPadding(dp(24), dp(16), dp(24), 0)
                    val val0 = P.i(s.k)
                    val label = TextView(this)
                    label.text = "$val0${s.u}"
                    label.textSize = 18f
                    val sb = SeekBar(this)
                    sb.max = s.max - s.min
                    sb.progress = val0 - s.min
                    sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(bar: SeekBar?, p: Int, u: Boolean) {
                            label.text = "${p + s.min}${s.u}"
                        }

                        override fun onStartTrackingTouch(bar: SeekBar?) {}
                        override fun onStopTrackingTouch(bar: SeekBar?) {}
                    })
                    lin.addView(label)
                    lin.addView(sb)
                    AlertDialog.Builder(this).setTitle(s.t).setView(lin)
                        .setPositiveButton("OK") { _, _ ->
                            P.put(s.k, sb.progress + s.min)
                            sub.text = "${P.i(s.k)}${s.u}"
                        }
                        .setNegativeButton("Отмена", null).show()
                }
                box.addView(r)
            }
            is Col -> {
                val names = listOf("Синий", "Зелёный", "Красный", "Оранжевый", "Фиолетовый", "Розовый", "Бирюзовый", "Жёлтый")
                val cols = listOf("#4C9AFF", "#3DDC84", "#FF5252", "#FF9800", "#B388FF", "#FF80AB", "#1DE9B6", "#FFD740").map { Color.parseColor(it) }
                val (r, sub) = twoLine(s.t)
                fun cur(): String = names.getOrElse(cols.indexOf(P.i(s.k))) { "Свой" }
                sub.text = cur()
                r.setOnClickListener {
                    AlertDialog.Builder(this).setTitle(s.t)
                        .setSingleChoiceItems(names.toTypedArray(), cols.indexOf(P.i(s.k))) { d, w ->
                            P.put(s.k, cols[w])
                            sub.text = cur()
                            d.dismiss()
                        }.show()
                }
                box.addView(r)
            }
            is Act -> {
                val r = LinearLayout(this)
                r.setPadding(dp(16), dp(14), dp(16), dp(14))
                r.addView(tv(s.t, 16f, fg))
                r.setOnClickListener { s.r() }
                box.addView(r)
            }
        }
    }

    // ───────────────────────── диалоги и файлы ─────────────────────────

    private fun hiddenDialog() {
        val apps = Apps.list.sortedBy { it.name().lowercase() }
        if (apps.isEmpty()) {
            toast("Список приложений ещё не загружен — откройте рабочий стол")
            return
        }
        val h = P.hidden()
        val checked = BooleanArray(apps.size) { apps[it].pkg in h }
        AlertDialog.Builder(this).setTitle("Скрытые приложения")
            .setMultiChoiceItems(apps.map { it.name() }.toTypedArray(), checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("OK") { _, _ ->
                P.put("hidden", apps.filterIndexed { i, _ -> checked[i] }.joinToString("\n") { it.pkg })
            }
            .setNegativeButton("Отмена", null).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data ?: return
        if (res != RESULT_OK) return
        try {
            if (req == reqExport) {
                contentResolver.openOutputStream(u)?.use { it.write(P.export().toByteArray()) }
                toast("Копия сохранена")
            } else if (req == reqImport) {
                val t = contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() } ?: return
                P.import(t)
                toast("Настройки восстановлены")
                recreate()
            }
        } catch (e: Exception) {
            toast("Ошибка: файл не подходит")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
