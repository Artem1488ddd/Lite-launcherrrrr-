package com.lite.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.app.Dialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast

/** Состояние перетаскивания. view — исходная ячейка (прячем на время), ghost — «призрак» под пальцем. */
private class Drag(
    val item: Item?, val pkg: String, val src: Int, val view: View?, val ghost: ImageView,
    val dx: Float, val dy: Float, val sx: Float, val sy: Float
) {
    var moved = false
    var edge = 0
}

class HomeActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var holder: FrameLayout
    private lateinit var dots: LinearLayout
    private lateinit var trash: TextView
    private var dockView: LinearLayout? = null
    private lateinit var drawer: LinearLayout
    private lateinit var grid: GridView
    private lateinit var search: EditText
    private val adapter = DrawerAdapter()
    private var shown: List<AppInfo> = emptyList()
    private lateinit var gd: GestureDetector
    private lateinit var host: AppWidgetHost
    private lateinit var awm: AppWidgetManager
    private val hd = Handler(Looper.getMainLooper())
    private var x0 = 0f
    private var y0 = 0f
    private var rawX = 0f
    private var rawY = 0f
    private var page = 0
    private var rev = -1
    private var drawerOpen = false
    private var torch = false
    private var drag: Drag? = null
    private var cancelPending = false
    private var resizingPkg: String? = null
    private var pendingId = -1
    private val reqBind = 21
    private val reqConfig = 22

    private val edgeRun = object : Runnable {
        override fun run() {
            val d = drag ?: return
            if (d.edge != 0) {
                setPage(page + d.edge, d.edge)
                hd.postDelayed(this, 900)
            }
        }
    }

    // ───────────────────────── жизненный цикл ─────────────────────────

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        P.init(this)
        Apps.loadCache(this)
        awm = AppWidgetManager.getInstance(this)
        host = AppWidgetHost(this, 1024)
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (resizingPkg != null) return false
                val dx = e2.x - x0
                val dy = e2.y - y0
                val ax = Math.abs(dx)
                val ay = Math.abs(dy)
                if (drawerOpen) {
                    if (dy > dp(80) && ay > ax * 1.5f && gridAtTop()) closeDrawer(false)
                    return false
                }
                if (ay > ax * 1.3f && ay > dp(60)) {
                    act(P.s(if (dy < 0) "gUp" else "gDown"))
                } else if (ax > ay * 1.3f && ax > dp(60)) {
                    val dir = if (dx < 0) 1 else -1
                    setPage(page + dir, dir)
                }
                return false
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!drawerOpen && resizingPkg == null) act(P.s("gDouble"))
                return false
            }
        })
        gd.setIsLongpressEnabled(false)
        build()
    }

    override fun onStart() {
        super.onStart()
        try {
            host.startListening()
        } catch (_: Throwable) {
        }
        Apps.refresh(this) { changed -> onApps(changed) }
    }

    override fun onStop() {
        super.onStop()
        try {
            host.stopListening()
        } catch (_: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        if (rev != P.rev()) build()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        if (i.action == Intent.ACTION_MAIN && i.hasCategory(Intent.CATEGORY_HOME)) {
            if (resizingPkg != null) {
                resizingPkg = null
                reload()
                return
            }
            if (drawerOpen) {
                closeDrawer(false)
                return
            }
            when (P.s("gHome")) {
                "reset" -> if (page != 0) setPage(0, -1)
                "drawer" -> openDrawer()
            }
        }
    }

    override fun onConfigurationChanged(n: Configuration) {
        super.onConfigurationChanged(n)
        build()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= 40) Icons.clear()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            drawerOpen -> closeDrawer(false)
            resizingPkg != null -> {
                resizingPkg = null
                reload()
            }
            page != 0 -> setPage(0, -1)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == reqBind) {
            if (res == RESULT_OK) configureOrPlace(pendingId) else dropWidgetId(pendingId)
        } else if (req == reqConfig) {
            if (res == RESULT_OK) placeWidget(pendingId) else dropWidgetId(pendingId)
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        rawX = ev.rawX
        rawY = ev.rawY
        val d = drag
        if (d != null) {
            if (cancelPending) {
                // дети, которые держали палец (долгое нажатие), получают CANCEL
                cancelPending = false
                val c = MotionEvent.obtain(ev)
                c.action = MotionEvent.ACTION_CANCEL
                super.dispatchTouchEvent(c)
                c.recycle()
            }
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> dragMove(d)
                MotionEvent.ACTION_UP -> dragEnd(d, false)
                MotionEvent.ACTION_CANCEL -> dragEnd(d, true)
            }
            return true
        }
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            x0 = ev.x
            y0 = ev.y
        }
        gd.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ───────────────────────── построение интерфейса ─────────────────────────

    private fun homeColor(): Int = if (P.s("homeText") == "black") Color.BLACK else Color.WHITE

    private fun shade(t: TextView) {
        if (P.b("shadow") && !P.b("lite")) t.setShadowLayer(4f, 0f, 1f, Color.BLACK)
    }

    private fun build() {
        drawerOpen = false
        var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        if (P.b("hideNav")) f = f or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        if (P.b("hideStatus")) f = f or View.SYSTEM_UI_FLAG_FULLSCREEN
        if (Build.VERSION.SDK_INT >= 23 && P.s("homeText") == "black") f = f or 0x2000
        window.decorView.systemUiVisibility = f
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        root = FrameLayout(this)
        home = LinearLayout(this)
        home.orientation = LinearLayout.VERTICAL
        root.addView(home, FrameLayout.LayoutParams(-1, -1))

        if (P.b("clock")) home.addView(clockBox())

        holder = FrameLayout(this)
        home.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))

        dots = LinearLayout(this)
        dots.gravity = Gravity.CENTER
        if (P.b("dots")) home.addView(dots, LinearLayout.LayoutParams(-1, dp(18)))

        dockView = null
        if (P.b("dockShow")) {
            val d = LinearLayout(this)
            d.orientation = LinearLayout.HORIZONTAL
            d.gravity = Gravity.CENTER
            d.setPadding(dp(6), dp(8), dp(6), dp(8))
            val bg = GradientDrawable()
            bg.cornerRadius = dp(P.i("dockRadius")).toFloat()
            bg.setColor(Th.withAlpha(Th.bg(this), P.i("dockAlpha")))
            d.background = bg
            val m = dp(P.i("dockMargin"))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(m, dp(4), m, m)
            home.addView(d, lp)
            dockView = d
        }

        trash = TextView(this)
        trash.text = "✕   Убрать"
        trash.gravity = Gravity.CENTER
        trash.setTextColor(Color.WHITE)
        trash.setBackgroundColor(Color.argb(210, 211, 47, 47))
        trash.visibility = View.GONE
        root.addView(trash, FrameLayout.LayoutParams(-1, dp(56)))

        buildDrawer()
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))

        root.setOnApplyWindowInsetsListener { _, ins ->
            val t = ins.systemWindowInsetTop
            val bt = ins.systemWindowInsetBottom
            home.setPadding(0, t, 0, bt)
            drawer.setPadding(dp(8), t + dp(8), dp(8), bt + dp(8))
            (trash.layoutParams as FrameLayout.LayoutParams).topMargin = t
            trash.requestLayout()
            ins
        }
        setContentView(root)
        page = page.coerceIn(0, P.i("pages") - 1)
        reload()
    }

    private fun clockBox(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(0, dp(16), 0, dp(8))
        val t = TextClock(this)
        t.format12Hour = "h:mm"
        t.format24Hour = "HH:mm"
        t.setTextColor(homeColor())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, P.i("clockSp").toFloat())
        t.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        shade(t)
        box.addView(t, LinearLayout.LayoutParams(-2, -2))
        if (P.b("date")) {
            val d = TextClock(this)
            d.format12Hour = "EEEE, d MMMM"
            d.format24Hour = "EEEE, d MMMM"
            d.setTextColor(homeColor())
            d.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            shade(d)
            box.addView(d, LinearLayout.LayoutParams(-2, -2))
        }
        return box
    }

    private fun buildDrawer() {
        val text = Th.text(this)
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.visibility = View.GONE
        drawer.isClickable = true
        drawer.setBackgroundColor(Th.withAlpha(Th.bg(this), if (P.b("lite")) 100 else P.i("dAlpha")))

        search = EditText(this)
        search.hint = "Поиск приложений"
        search.setHintTextColor(Th.withAlpha(text, 50))
        search.setTextColor(text)
        search.isSingleLine = true
        search.imeOptions = EditorInfo.IME_ACTION_GO
        search.setPadding(dp(16), dp(10), dp(16), dp(10))
        val sbg = GradientDrawable()
        sbg.cornerRadius = dp(24).toFloat()
        sbg.setColor(Th.withAlpha(text, 12))
        search.background = sbg
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                applyFilter((s?.toString() ?: "").trim())
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        search.setOnEditorActionListener { _, _, _ ->
            shown.firstOrNull()?.let { launch(it, null) }
            true
        }

        grid = GridView(this)
        grid.numColumns = if (P.b("dList")) 1 else P.i("dCols")
        grid.adapter = adapter
        grid.selector = ColorDrawable(Th.withAlpha(text, 15))
        grid.isFastScrollEnabled = true
        grid.verticalSpacing = dp(10)
        grid.onItemClickListener = AdapterView.OnItemClickListener { _, v, p, _ -> launch(shown[p], v) }
        grid.onItemLongClickListener = AdapterView.OnItemLongClickListener { _, v, p, _ ->
            startDrag(v, null, shown[p].pkg, 0)
            true
        }

        val sp = LinearLayout.LayoutParams(-1, -2)
        sp.setMargins(0, dp(4), 0, dp(8))
        val pos = P.s("search")
        if (pos == "top") drawer.addView(search, sp)
        drawer.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        if (pos == "bottom") drawer.addView(search, sp)
    }

    private inner class DrawerAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val list = P.b("dList")
            val v = convertView as? AppCell ?: AppCell(
                this@HomeActivity, list, P.i("dIcon"), P.i("labelSp") + (if (list) 3 else 0),
                true, Th.text(this@HomeActivity), false, false
            ).also {
                if (list) it.setPadding(dp(14), dp(6), dp(14), dp(6)) else it.setPadding(dp(2), dp(4), dp(2), dp(4))
            }
            v.bind(shown[position])
            return v
        }
    }

    // ───────────────────────── рабочий стол ─────────────────────────

    private fun reload() {
        holder.removeAllViews()
        setPage(page, 0)
        fillDock()
        rev = P.rev()
        if (resizingPkg != null) showResize()
    }

    private fun makePage(p: Int): Grid {
        val cols = P.i("cols")
        val rows = P.i("rows")
        val g = Grid(this, cols, rows)
        val e = dp(P.i("edge"))
        g.setPadding(e, dp(4), e, dp(4))
        val its = P.items()
        val dg = drag
        for (x in its) {
            if (x.page != p || x.cell >= cols * rows) continue
            if (dg != null && dg.item != null && dg.item.pkg == x.pkg) continue // его сейчас несут
            val v: View = when {
                x.isWidget -> widgetCell(x)
                x.isFolder -> folderCell(x)
                else -> Apps.find(x.pkg)?.let { homeCell(it, x) }
            } ?: continue
            g.addView(v)
        }
        if (p == 0 && its.isEmpty() && Apps.list.isNotEmpty()) {
            val h = TextView(this)
            h.text = "Свайп вверх — все приложения.\nУдерживайте приложение и тащите на стол.\nДолгое нажатие на пустое место — виджеты."
            h.gravity = Gravity.CENTER
            h.setTextColor(homeColor())
            shade(h)
            g.addView(h)
        }
        g.setOnLongClickListener {
            act(P.s("gLong"))
            true
        }
        return g
    }

    private fun homeCell(a: AppInfo, x: Item): AppCell {
        val big = Math.min(x.w, x.h)
        val c = AppCell(this, false, P.i("iconDp") * big, P.i("labelSp") + (big - 1) * 2, P.b("showLabels"), homeColor(), P.b("shadow"), true)
        c.tag = x
        val g = dp(P.i("gap"))
        c.setPadding(g, g, g, g)
        c.bind(a)
        c.setOnClickListener { launch(a, c) }
        c.setOnLongClickListener {
            startDrag(c, x, a.pkg, 1)
            true
        }
        return c
    }

    private fun folderCell(x: Item): View {
        val f = P.folder(x.id)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.tag = x
        val g = dp(P.i("gap"))
        box.setPadding(g, g, g, g)
        val pv = Grid(this, 2 * x.w, 2 * x.h)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(Th.withAlpha(Color.WHITE, 24))
        pv.background = bg
        pv.setPadding(dp(4), dp(4), dp(4), dp(4))
        var i = 0
        for (pkg in f.second) {
            if (i >= 4 * x.w * x.h) break
            val a = Apps.find(pkg) ?: continue
            val iv = IconView(this)
            iv.square = true
            Icons.bind(iv, a)
            val wr = FrameLayout(this)
            wr.setPadding(dp(3), dp(3), dp(3), dp(3))
            wr.addView(iv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            wr.tag = Item(pkg, 0, i)
            pv.addView(wr)
            i++
        }
        box.addView(pv, LinearLayout.LayoutParams(-1, 0, 1f))
        if (P.b("showLabels")) {
            val t = TextView(this)
            t.text = f.first.ifEmpty { "Папка" }
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, P.i("labelSp") * P.i("scale") / 100f)
            t.setTextColor(homeColor())
            t.maxLines = 1
            t.gravity = Gravity.CENTER
            t.setPadding(0, dp(3), 0, 0)
            shade(t)
            box.addView(t, LinearLayout.LayoutParams(-1, -2))
        }
        box.setOnClickListener { openFolder(x) }
        box.setOnLongClickListener {
            startDrag(box, x, x.pkg, 1)
            true
        }
        return box
    }

    private fun widgetCell(x: Item): View? {
        val info = awm.getAppWidgetInfo(x.id) ?: return null
        val hv = try {
            host.createView(this, x.id, info)
        } catch (_: Throwable) {
            return null
        }
        val fr = LongFrame(this) { v -> startDrag(v, x, x.pkg, 1) }
        fr.addView(hv, FrameLayout.LayoutParams(-1, -1))
        fr.tag = x
        return fr
    }

    private fun fillDock() {
        val d = dockView ?: return
        d.removeAllViews()
        val textCol = if (P.i("dockAlpha") >= 60) Th.text(this) else homeColor()
        for (pkg in P.dock().take(P.i("dockN"))) {
            val a = Apps.find(pkg) ?: continue
            val c = AppCell(this, false, P.i("dockIcon"), P.i("labelSp"), P.b("dockLabels"), textCol, P.b("shadow"), true)
            c.bind(a)
            c.setOnClickListener { launch(a, c) }
            c.setOnLongClickListener {
                startDrag(c, null, pkg, 2)
                true
            }
            d.addView(c, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
    }

    private fun setPage(n: Int, dir: Int) {
        val pages = P.i("pages")
        var t = n
        if (t < 0) t = if (P.b("infinite")) pages - 1 else 0
        if (t >= pages) t = if (P.b("infinite")) 0 else pages - 1
        while (holder.childCount > 1) holder.removeViewAt(0)
        val old = if (holder.childCount > 0) holder.getChildAt(0) else null
        if (dir != 0 && t == page) return
        val g = makePage(t)
        holder.addView(g)
        page = t
        updateDots()
        if (old == null) return
        if (dir != 0 && animOn()) {
            val w = holder.width.toFloat()
            val d = animMs()
            when (P.s("pageFx")) {
                "fade" -> {
                    g.alpha = 0f
                    g.animate().alpha(1f).setDuration(d)
                    old.animate().alpha(0f).setDuration(d).withEndAction { holder.removeView(old) }
                }
                "zoom" -> {
                    g.alpha = 0f
                    g.scaleX = 0.85f
                    g.scaleY = 0.85f
                    g.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(d)
                    old.animate().alpha(0f).scaleX(1.15f).scaleY(1.15f).setDuration(d)
                        .withEndAction { holder.removeView(old) }
                }
                else -> {
                    g.translationX = dir * w
                    g.animate().translationX(0f).setDuration(d)
                    old.animate().translationX(-dir * w).setDuration(d).withEndAction { holder.removeView(old) }
                }
            }
        } else {
            holder.removeView(old)
        }
    }

    private fun updateDots() {
        if (!P.b("dots")) return
        dots.removeAllViews()
        val n = P.i("pages")
        val s = dp(P.i("dotSize"))
        val acc = Th.accent(this)
        for (i in 0 until n) {
            val v = View(this)
            val bg = GradientDrawable()
            bg.shape = GradientDrawable.OVAL
            bg.setColor(if (i == page) acc else Th.withAlpha(Color.WHITE, 45))
            v.background = bg
            val lp = LinearLayout.LayoutParams(s, s)
            lp.setMargins(s / 2, 0, s / 2, 0)
            dots.addView(v, lp)
        }
    }

    private fun compact(l: List<Item>): List<Item> {
        val out = ArrayList<Item>()
        val pg = maxOf(P.i("pages"), (l.maxOfOrNull { it.page } ?: 0) + 1)
        for (p in 0 until pg) {
            // выравниваем только одиночные ячейки; растянутые элементы остаются на местах
            val here = l.filter { it.page == p }
            val big = here.filter { it.w > 1 || it.h > 1 }
            out.addAll(big)
            val cols = P.i("cols")
            var c = 0
            for (x in here.filter { it.w == 1 && it.h == 1 }.sortedBy { it.cell }) {
                while (Lay.overlaps(big, p, c % cols, c / cols, 1, 1, cols, null) != null) c++
                out.add(Item(x.pkg, p, c))
                c++
            }
        }
        return out
    }

    // ───────────────────────── перетаскивание ─────────────────────────

    private fun startDrag(v: View, item: Item?, pkg: String, src: Int) {
        if (P.b("lock")) {
            showMenuFor(item, pkg, src)
            return
        }
        if (v.width <= 0 || v.height <= 0) return
        val bmp = try {
            Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        } catch (_: Throwable) {
            return
        }
        v.draw(Canvas(bmp))
        val ghost = ImageView(this)
        ghost.setImageBitmap(bmp)
        ghost.alpha = 0.9f
        val l = IntArray(2)
        v.getLocationOnScreen(l)
        val rl = IntArray(2)
        root.getLocationOnScreen(rl)
        root.addView(ghost, FrameLayout.LayoutParams(v.width, v.height))
        ghost.translationX = (l[0] - rl[0]).toFloat()
        ghost.translationY = (l[1] - rl[1]).toFloat()
        if (src != 0) {
            v.alpha = 0f
            trash.visibility = View.VISIBLE
        }
        drag = Drag(item, pkg, src, v, ghost, rawX - l[0], rawY - l[1], rawX, rawY)
        cancelPending = true
        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun dragMove(d: Drag) {
        val rl = IntArray(2)
        root.getLocationOnScreen(rl)
        d.ghost.translationX = rawX - d.dx - rl[0]
        d.ghost.translationY = rawY - d.dy - rl[1]
        if (!d.moved && (Math.abs(rawX - d.sx) > dp(10) || Math.abs(rawY - d.sy) > dp(10))) {
            d.moved = true
            if (d.src == 0 && drawerOpen) closeDrawer(true)
        }
        if (!d.moved) return
        val z = dp(36)
        val dir = if (rawX < z) -1 else if (rawX > root.width - z) 1 else 0
        if (dir != d.edge) {
            d.edge = dir
            hd.removeCallbacks(edgeRun)
            if (dir != 0) hd.postDelayed(edgeRun, 700)
        }
    }

    private fun dragEnd(d: Drag, cancel: Boolean) {
        hd.removeCallbacks(edgeRun)
        var inTrash = false
        if (trash.visibility == View.VISIBLE) {
            val tl = IntArray(2)
            trash.getLocationOnScreen(tl)
            inTrash = rawY < tl[1] + trash.height
        }
        root.removeView(d.ghost)
        trash.visibility = View.GONE
        drag = null
        d.view?.alpha = 1f
        if (cancel) {
            reload()
            return
        }
        if (!d.moved) {
            showMenuFor(d.item, d.pkg, d.src)
            return
        }
        var inDock = false
        val dv = dockView
        if (dv != null) {
            val dl = IntArray(2)
            dv.getLocationOnScreen(dl)
            val m = dp(10)
            inDock = rawX > dl[0] - m && rawX < dl[0] + dv.width + m && rawY > dl[1] - m && rawY < dl[1] + dv.height + m
        }
        when {
            inTrash -> removeItem(d.pkg, d.src == 2)
            inDock -> dropToDock(d)
            else -> dropToGrid(d)
        }
    }

    private fun dropToDock(d: Drag) {
        if (d.item != null && !d.item.isApp) {
            toast("В док можно класть только приложения")
            reload()
            return
        }
        val dock = P.dock()
        val dv = dockView
        var idx = dock.size
        if (dv != null) {
            idx = 0
            for (i in 0 until dv.childCount) {
                val c = dv.getChildAt(i)
                val cl = IntArray(2)
                c.getLocationOnScreen(cl)
                if (rawX > cl[0] + c.width / 2) idx = i + 1
            }
        }
        val was = dock.indexOf(d.pkg)
        if (was >= 0) {
            dock.removeAt(was)
            if (was < idx) idx--
        } else if (dock.size >= P.i("dockN")) {
            toast("Док заполнен")
            reload()
            return
        }
        dock.add(idx.coerceIn(0, dock.size), d.pkg)
        P.saveDock(dock)
        if (d.item != null) P.saveItems(P.items().filter { it.pkg != d.pkg })
        reload()
    }

    private fun dropToGrid(d: Drag) {
        val g = holder.getChildAt(holder.childCount - 1) as? Grid
        if (g == null) {
            reload()
            return
        }
        val its = P.items()
        val cur = its.firstOrNull { it.pkg == d.pkg }
        val w = cur?.w ?: 1
        val h = cur?.h ?: 1
        val cols = g.cols
        val rows = g.rows
        val gl = IntArray(2)
        g.getLocationOnScreen(gl)
        val cw = ((g.width - g.paddingLeft - g.paddingRight) / cols).coerceAtLeast(1)
        val ch = ((g.height - g.paddingTop - g.paddingBottom) / rows).coerceAtLeast(1)
        val px: Float
        val py: Float
        if (w == 1 && h == 1) {
            px = rawX - gl[0]
            py = rawY - gl[1]
        } else {
            px = rawX - d.dx - gl[0] + cw / 2f
            py = rawY - d.dy - gl[1] + ch / 2f
        }
        val cell = g.cellAt(px, py)
        val cx = (cell % cols).coerceAtMost(cols - w).coerceAtLeast(0)
        val cy = (cell / cols).coerceAtMost(rows - h).coerceAtLeast(0)
        val hit = Lay.overlaps(its, page, cx, cy, w, h, cols, cur)
        val isApp = cur?.isApp ?: true
        if (hit == null) {
            if (cur != null) {
                cur.page = page
                cur.cell = cy * cols + cx
            } else {
                its.add(Item(d.pkg, page, cy * cols + cx))
            }
        } else if (isApp && w == 1 && h == 1 && hit.isApp && hit.pkg != d.pkg) {
            // приложение на приложение → новая папка
            val id = ((System.currentTimeMillis() / 10) % 1000000000L).toInt()
            P.saveFolder(id, "Папка", listOf(hit.pkg, d.pkg))
            its.remove(hit)
            if (cur != null) its.remove(cur)
            its.add(Item("folder:$id", hit.page, hit.cell, hit.w, hit.h))
        } else if (isApp && w == 1 && h == 1 && hit.isFolder) {
            // приложение на папку → внутрь
            val f = P.folder(hit.id)
            if (d.pkg !in f.second) {
                f.second.add(d.pkg)
                P.saveFolder(hit.id, f.first, f.second)
            }
            if (cur != null) its.remove(cur)
        } else {
            toast("Место занято")
            reload()
            return
        }
        P.saveItems(its)
        if (d.src == 2) P.saveDock(P.dock().filter { it != d.pkg })
        reload()
    }

    private fun removeItem(pkg: String, fromDock: Boolean) {
        val its = P.items()
        val x = its.firstOrNull { it.pkg == pkg }
        if (x != null) {
            if (x.isWidget) dropWidgetId(x.id)
            if (x.isFolder) P.deleteFolder(x.id)
        }
        var l: List<Item> = its.filter { it.pkg != pkg }
        if (P.b("align")) l = compact(l)
        P.saveItems(l)
        if (fromDock) P.saveDock(P.dock().filter { it != pkg })
        reload()
    }

    private fun findFree(its: List<Item>, w: Int, h: Int): Pair<Int, Int>? {
        val cols = P.i("cols")
        val rows = P.i("rows")
        val pages = P.i("pages")
        for (k in 0 until pages) {
            val p = (page + k) % pages
            for (y in 0..rows - h) {
                for (x in 0..cols - w) {
                    if (Lay.overlaps(its, p, x, y, w, h, cols, null) == null) return Pair(p, y * cols + x)
                }
            }
        }
        return null
    }

    private fun placeApp(pkg: String): Boolean {
        val its = P.items()
        if (its.any { it.pkg == pkg }) {
            toast("Уже на рабочем столе")
            return false
        }
        val pos = findFree(its, 1, 1)
        if (pos == null) {
            toast("Нет места на столах")
            return false
        }
        its.add(Item(pkg, pos.first, pos.second))
        P.saveItems(its)
        reload()
        return true
    }

    // ───────────────────────── растягивание ─────────────────────────

    private fun startResize(pkg: String) {
        resizingPkg = pkg
        reload()
        toast("Тяните за кружки в углах. Коснитесь вне рамки — готово")
    }

    private fun showResize() {
        val pkg = resizingPkg ?: return
        val its = P.items()
        val me = its.firstOrNull { it.pkg == pkg }
        if (me == null) {
            resizingPkg = null
            return
        }
        val g = holder.getChildAt(holder.childCount - 1) as? Grid ?: return
        val cols = P.i("cols")
        val ov = ResizeOverlay(
            this, cols, P.i("rows"), me.cell % cols, me.cell / cols, me.w, me.h,
            g.paddingLeft, g.paddingTop, g.paddingRight, g.paddingBottom, Th.accent(this),
            { x, y, w, h -> Lay.overlaps(its, me.page, x, y, w, h, cols, me) == null },
            { x, y, w, h ->
                me.cell = y * cols + x
                me.w = w
                me.h = h
                P.saveItems(its)
                reload()
            },
            {
                resizingPkg = null
                reload()
            }
        )
        holder.addView(ov, FrameLayout.LayoutParams(-1, -1))
    }

    // ───────────────────────── виджеты ─────────────────────────

    private fun widgetPicker() {
        val pm = packageManager
        val l = try {
            awm.installedProviders.sortedBy { (it.loadLabel(pm) ?: "").lowercase() }
        } catch (_: Throwable) {
            emptyList()
        }
        if (l.isEmpty()) {
            toast("Виджетов не найдено")
            return
        }
        val names = l.map { (it.loadLabel(pm) ?: "?") + " — " + it.provider.packageName }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Добавить виджет").setItems(names) { _, i -> addWidget(l[i]) }.show()
    }

    private fun addWidget(info: android.appwidget.AppWidgetProviderInfo) {
        try {
            val id = host.allocateAppWidgetId()
            pendingId = id
            if (awm.bindAppWidgetIdIfAllowed(id, info.provider)) {
                configureOrPlace(id)
            } else {
                val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                startActivityForResult(i, reqBind)
            }
        } catch (e: Exception) {
            toast("Не удалось добавить виджет")
        }
    }

    private fun configureOrPlace(id: Int) {
        pendingId = id
        val info = awm.getAppWidgetInfo(id)
        if (info?.configure != null) {
            try {
                host.startAppWidgetConfigureActivityForResult(this, id, 0, reqConfig, null)
                return
            } catch (_: Exception) {
            }
        }
        placeWidget(id)
    }

    private fun placeWidget(id: Int) {
        val info = awm.getAppWidgetInfo(id)
        if (info == null) {
            dropWidgetId(id)
            return
        }
        val cols = P.i("cols")
        val rows = P.i("rows")
        val cw = ((holder.width - 2 * dp(P.i("edge"))) / cols).coerceAtLeast(1)
        val ch = ((holder.height - dp(8)) / rows).coerceAtLeast(1)
        var w = Math.ceil(info.minWidth.toDouble() / cw).toInt().coerceIn(1, cols)
        var h = Math.ceil(info.minHeight.toDouble() / ch).toInt().coerceIn(1, rows)
        val its = P.items()
        var pos = findFree(its, w, h)
        while (pos == null && (w > 1 || h > 1)) {
            if (w >= h && w > 1) w-- else h--
            pos = findFree(its, w, h)
        }
        if (pos == null) {
            toast("Нет места для виджета")
            dropWidgetId(id)
            return
        }
        its.add(Item("widget:$id", pos.first, pos.second, w, h))
        P.saveItems(its)
        page = pos.first
        reload()
        toast("Удерживайте виджет, чтобы изменить размер или убрать")
    }

    private fun dropWidgetId(id: Int) {
        try {
            host.deleteAppWidgetId(id)
        } catch (_: Throwable) {
        }
    }

    // ───────────────────────── папки ─────────────────────────

    private fun openFolder(x: Item) {
        val f = P.folder(x.id)
        val apps = f.second
        val text = Th.text(this)
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(16), dp(12), dp(16), dp(16))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(24).toFloat()
        bg.setColor(Th.withAlpha(Th.bg(this), 96))
        box.background = bg

        val title = EditText(this)
        title.setText(f.first.ifEmpty { "Папка" })
        title.gravity = Gravity.CENTER
        title.setTextColor(text)
        title.isSingleLine = true
        title.background = null
        title.textSize = 18f
        box.addView(title, LinearLayout.LayoutParams(-1, -2))

        val list = ArrayList<AppInfo>()
        fun refresh() {
            list.clear()
            for (pkg in apps) Apps.find(pkg)?.let { list.add(it) }
        }
        refresh()
        val gv = GridView(this)
        gv.numColumns = 4
        gv.verticalSpacing = dp(8)
        gv.selector = ColorDrawable(Th.withAlpha(text, 15))
        val ad = object : BaseAdapter() {
            override fun getCount(): Int = list.size
            override fun getItem(position: Int): Any = list[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val v = convertView as? AppCell ?: AppCell(this@HomeActivity, false, 48, 11, true, text, false, false)
                v.bind(list[position])
                return v
            }
        }
        gv.adapter = ad
        gv.setOnItemClickListener { _, v, p, _ ->
            dlg.dismiss()
            launch(list[p], v)
        }
        gv.setOnItemLongClickListener { _, _, p, _ ->
            folderAppMenu(x, list[p].pkg, apps) {
                refresh()
                ad.notifyDataSetChanged()
                if (list.isEmpty()) dlg.dismiss()
            }
            true
        }
        box.addView(gv, LinearLayout.LayoutParams(-1, -2))
        dlg.setContentView(box)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dlg.setOnDismissListener {
            if (apps.isNotEmpty()) {
                P.saveFolder(x.id, title.text.toString().trim().ifEmpty { "Папка" }, apps)
                reload()
            }
        }
        dlg.show()
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun folderAppMenu(x: Item, pkg: String, apps: MutableList<String>, after: () -> Unit) {
        val ls = arrayOf("Вынести на рабочий стол", "О приложении", "Удалить")
        AlertDialog.Builder(this).setItems(ls) { _, i ->
            when (i) {
                0 -> if (placeApp(pkg)) {
                    apps.remove(pkg)
                    val name = P.folder(x.id).first
                    if (apps.isEmpty()) {
                        P.saveItems(P.items().filter { it.pkg != x.pkg })
                        P.deleteFolder(x.id)
                    } else {
                        P.saveFolder(x.id, name, apps)
                    }
                    reload()
                }
                1 -> info(pkg)
                2 -> uninstall(pkg)
            }
            after()
        }.show()
    }

    private fun renameFolder(x: Item) {
        val f = P.folder(x.id)
        val e = EditText(this)
        e.setText(f.first)
        e.isSingleLine = true
        AlertDialog.Builder(this).setTitle("Название папки").setView(e)
            .setPositiveButton("OK") { _, _ ->
                P.saveFolder(x.id, e.text.toString().trim().ifEmpty { "Папка" }, f.second)
                reload()
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun dissolve(x: Item) {
        val f = P.folder(x.id)
        P.saveItems(P.items().filter { it.pkg != x.pkg })
        for (pkg in f.second) if (Apps.find(pkg) != null) placeApp(pkg)
        P.deleteFolder(x.id)
        reload()
    }

    // ───────────────────────── меню приложений ─────────────────────────

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        search.setText("")
        applyFilter("")
        grid.setSelection(0)
        drawer.animate().cancel()
        drawer.visibility = View.VISIBLE
        resetDrawer()
        if (animOn()) {
            val d = animMs()
            when (P.s("animType")) {
                "fade" -> {
                    drawer.alpha = 0f
                    drawer.animate().alpha(1f).setDuration(d)
                }
                "zoom" -> {
                    drawer.alpha = 0f
                    drawer.scaleX = 0.9f
                    drawer.scaleY = 0.9f
                    drawer.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(d)
                }
                else -> {
                    drawer.translationY = root.height.toFloat()
                    drawer.animate().translationY(0f).setDuration(d)
                }
            }
        }
        if (P.b("autoKb") && P.s("search") != "off") {
            search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, 0)
        }
    }

    private fun resetDrawer() {
        drawer.alpha = 1f
        drawer.translationY = 0f
        drawer.scaleX = 1f
        drawer.scaleY = 1f
    }

    private fun closeDrawer(instant: Boolean) {
        if (!drawerOpen) return
        drawerOpen = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        drawer.animate().cancel()
        val end = Runnable {
            drawer.visibility = View.GONE
            resetDrawer()
        }
        if (instant || !animOn()) {
            end.run()
            return
        }
        val a = drawer.animate().setDuration(animMs())
        when (P.s("animType")) {
            "fade" -> a.alpha(0f)
            "zoom" -> a.alpha(0f).scaleX(0.9f).scaleY(0.9f)
            else -> a.translationY(root.height.toFloat())
        }
        a.withEndAction(end)
    }

    private fun gridAtTop(): Boolean {
        if (grid.childCount == 0) return true
        return grid.firstVisiblePosition == 0 && grid.getChildAt(0).top >= 0
    }

    private fun applyFilter(q: String) {
        val hidden = P.hidden()
        var l = Apps.list.filter { it.pkg !in hidden }
        if (q.isNotEmpty()) {
            val s = q.lowercase()
            l = l.filter { it.name().lowercase().contains(s) }.sortedBy { !it.name().lowercase().startsWith(s) }
        } else {
            l = when (P.s("dSort")) {
                "freq" -> l.sortedByDescending { P.usage.getInt("c_" + it.pkg, 0) }
                "recent" -> l.sortedByDescending { P.usage.getLong("t_" + it.pkg, 0L) }
                else -> l.sortedBy { it.name().lowercase() }
            }
        }
        shown = l
        adapter.notifyDataSetChanged()
    }

    // ───────────────────────── действия ─────────────────────────

    private fun onApps(changed: Boolean) {
        if (Apps.list.isEmpty()) return
        if (rev != P.rev()) build()
        var need = changed
        if (!P.b("init")) {
            seed()
            need = true
        }
        val valid = Apps.list.map { it.pkg }.toSet()
        val its = P.items()
        val keep = its.filter { !it.isApp || it.pkg in valid }
        if (keep.size != its.size) {
            P.saveItems(keep)
            need = true
        }
        val d = P.dock()
        val kd = d.filter { it in valid }
        if (kd.size != d.size) {
            P.saveDock(kd)
            need = true
        }
        if (need) {
            reload()
            if (drawerOpen) applyFilter(search.text.toString().trim())
        }
    }

    /** Первый запуск: в док кладём звонилку, SMS, браузер и камеру (если есть). */
    private fun seed() {
        val ints = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent("android.media.action.IMAGE_CAPTURE")
        )
        val d = ArrayList<String>()
        for (i in ints) {
            val p = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            if (p != null && p != "android" && Apps.find(p) != null && p !in d) d.add(p)
        }
        P.saveDock(d)
        P.put("init", true)
    }

    private fun act(a: String) {
        when (a) {
            "drawer" -> openDrawer()
            "notif" -> notif()
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
            "torch" -> toggleTorch()
            "first" -> if (page != 0) setPage(0, -1)
            "menu" -> desktopMenu()
        }
    }

    private fun desktopMenu() {
        val ls = ArrayList<String>()
        val ac = ArrayList<() -> Unit>()
        if (!P.b("lock")) {
            ls.add("Добавить виджет")
            ac.add { widgetPicker() }
        }
        ls.add("Настройки лаунчера")
        ac.add { act("settings") }
        ls.add("Сменить обои")
        ac.add {
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои"))
            } catch (_: Exception) {
            }
        }
        AlertDialog.Builder(this).setItems(ls.toTypedArray()) { _, i -> ac[i]() }.show()
    }

    private fun launch(a: AppInfo, anchor: View?) {
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(ComponentName(a.pkg, a.cls))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            val anim = animOn()
            val opt: Bundle? = if (!anim) null else when (P.s("launchAnim")) {
                "zoom" -> if (anchor != null) ActivityOptions.makeScaleUpAnimation(anchor, 0, 0, anchor.width, anchor.height).toBundle() else null
                "fade" -> ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()
                "slide" -> ActivityOptions.makeCustomAnimation(this, android.R.anim.slide_in_left, android.R.anim.slide_out_right).toBundle()
                else -> null
            }
            startActivity(i, opt)
            if (!anim) overridePendingTransition(0, 0)
            P.bump(a.pkg)
            if (drawerOpen) closeDrawer(true)
        } catch (e: Exception) {
            toast("Не удалось открыть")
        }
    }

    private fun showMenuFor(item: Item?, pkg: String, src: Int) {
        when {
            item != null && item.isWidget -> widgetMenu(item)
            item != null && item.isFolder -> folderMenu(item)
            else -> Apps.find(pkg)?.let { menu(it, src) }
        }
    }

    private fun widgetMenu(x: Item) {
        val ls = ArrayList<String>()
        val ac = ArrayList<() -> Unit>()
        if (!P.b("lock")) {
            ls.add("Изменить размер")
            ac.add { startResize(x.pkg) }
            ls.add("Убрать виджет")
            ac.add { removeItem(x.pkg, false) }
        }
        if (ls.isEmpty()) return
        AlertDialog.Builder(this).setItems(ls.toTypedArray()) { _, i -> ac[i]() }.show()
    }

    private fun folderMenu(x: Item) {
        val ls = ArrayList<String>()
        val ac = ArrayList<() -> Unit>()
        ls.add("Открыть")
        ac.add { openFolder(x) }
        if (!P.b("lock")) {
            ls.add("Переименовать")
            ac.add { renameFolder(x) }
            ls.add("Изменить размер")
            ac.add { startResize(x.pkg) }
            ls.add("Распустить папку")
            ac.add { dissolve(x) }
            ls.add("Удалить папку")
            ac.add { removeItem(x.pkg, false) }
        }
        AlertDialog.Builder(this).setTitle(P.folder(x.id).first.ifEmpty { "Папка" }).setItems(ls.toTypedArray()) { _, i -> ac[i]() }.show()
    }

    private fun menu(a: AppInfo, src: Int) {
        val ls = ArrayList<String>()
        val ac = ArrayList<() -> Unit>()
        fun add(t: String, r: () -> Unit) {
            ls.add(t)
            ac.add(r)
        }
        val lock = P.b("lock")
        when (src) {
            0 -> {
                if (!lock) {
                    add("На рабочий стол") {
                        if (placeApp(a.pkg)) closeDrawer(true)
                    }
                    if (P.b("dockShow")) add("В док") { toDock(a.pkg) }
                }
                add("Скрыть") { hide(a.pkg) }
            }
            1 -> if (!lock) {
                add("Изменить размер") { startResize(a.pkg) }
                add("Убрать с экрана") { removeItem(a.pkg, false) }
            }
            2 -> if (!lock) add("Убрать из дока") {
                P.saveDock(P.dock().filter { it != a.pkg })
                reload()
            }
        }
        add("Переименовать") { rename(a) }
        add("О приложении") { info(a.pkg) }
        add("Удалить") { uninstall(a.pkg) }
        AlertDialog.Builder(this).setTitle(a.name()).setItems(ls.toTypedArray()) { _, i -> ac[i]() }.show()
    }

    private fun toDock(pkg: String) {
        val d = P.dock()
        if (pkg in d) return
        if (d.size >= P.i("dockN")) {
            toast("Док заполнен")
            return
        }
        d.add(pkg)
        P.saveDock(d)
        reload()
        toast("Добавлено в док")
    }

    private fun hide(pkg: String) {
        val h = P.hidden()
        h.add(pkg)
        P.put("hidden", h.joinToString("\n"))
        rev = P.rev()
        applyFilter(search.text.toString().trim())
        toast("Скрыто. Вернуть: Настройки → Скрытые приложения")
    }

    private fun rename(a: AppInfo) {
        val e = EditText(this)
        e.setText(a.name())
        e.isSingleLine = true
        AlertDialog.Builder(this).setTitle("Название").setView(e)
            .setPositiveButton("OK") { _, _ ->
                P.setName(a.pkg, e.text.toString())
                reload()
                if (drawerOpen) applyFilter(search.text.toString().trim())
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun info(pkg: String) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
        } catch (_: Exception) {
        }
    }

    private fun uninstall(pkg: String) {
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
        } catch (_: Exception) {
        }
    }

    private fun notif() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (_: Throwable) {
        }
    }

    private fun toggleTorch() {
        if (Build.VERSION.SDK_INT < 23) return
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            torch = !torch
            cm.setTorchMode(id, torch)
        } catch (e: Exception) {
            toast("Фонарик недоступен")
        }
    }

    // ───────────────────────── анимации ─────────────────────────

    private fun animMs(): Long = P.i("animMs").toLong()

    private fun animOn(): Boolean {
        if (!P.b("anim") || P.b("lite")) return false
        if (P.b("animAuto")) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (pm.isPowerSaveMode) return false
            val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (bi != null) {
                val lvl = bi.getIntExtra("level", 100)
                val sc = bi.getIntExtra("scale", 100).coerceAtLeast(1)
                if (bi.getIntExtra("plugged", 0) == 0 && lvl * 100 / sc < 15) return false
            }
        }
        return true
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
