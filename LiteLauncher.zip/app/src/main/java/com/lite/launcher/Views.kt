package com.lite.launcher

import android.appwidget.AppWidgetHostView
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

object Gray {
    val f = ColorMatrixColorFilter(ColorMatrix().also { it.setSaturation(0f) })
}

fun shapeFrac(): Float = when (P.s("shape")) {
    "circle" -> 0.5f
    "round" -> 0.22f
    "square" -> 0.06f
    else -> 0.36f
}

/** Иконка нужной формы: форма задаётся обрезкой по контуру. */
class IconView(c: Context) : ImageView(c) {
    var square = false

    init {
        scaleType = ScaleType.FIT_XY
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.width * shapeFrac())
            }
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        if (square) {
            val s = Math.min(MeasureSpec.getSize(w), MeasureSpec.getSize(h))
            setMeasuredDimension(s, s)
        } else {
            super.onMeasure(w, h)
        }
    }
}

/** Одна ячейка приложения: иконка + подпись. Используется на столе, в доке и в меню. */
class AppCell(
    c: Context, horizontal: Boolean, iconDp: Int, labelSp: Int, showLabel: Boolean,
    textColor: Int, shadow: Boolean, clickable: Boolean
) : LinearLayout(c) {
    val icon = IconView(c)
    val label = TextView(c)
    var app: AppInfo? = null

    init {
        val sc = P.i("scale") / 100f
        orientation = if (horizontal) HORIZONTAL else VERTICAL
        gravity = if (horizontal) Gravity.CENTER_VERTICAL else Gravity.CENTER
        val s = c.dp(iconDp * sc)
        addView(icon, LinearLayout.LayoutParams(s, s))
        if (P.b("mono")) icon.colorFilter = Gray.f

        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, labelSp * sc)
        label.setTextColor(textColor)
        label.ellipsize = TextUtils.TruncateAt.END
        if (shadow && !P.b("lite")) label.setShadowLayer(3f, 0f, 1f, Color.BLACK)
        if (horizontal) {
            label.maxLines = 1
            label.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            label.setPadding(c.dp(14), 0, 0, 0)
            addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        } else if (showLabel) {
            label.maxLines = P.i("lines")
            label.gravity = Gravity.CENTER
            label.setPadding(c.dp(2), c.dp(3), c.dp(2), 0)
            addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        isClickable = clickable
        if (clickable && !P.b("lite")) {
            val st = StateListDrawable()
            st.addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable(0x33FFFFFF))
            background = st
        }
    }

    fun bind(a: AppInfo) {
        app = a
        Icons.bind(icon, a)
        label.text = a.name()
    }
}

/**
 * Сетка рабочего стола. Положение и размер каждого ребёнка берутся из его tag (Item):
 * ячейка = col + row * cols, размер = w x h ячеек. Ребёнок без tag растягивается на всё поле.
 */
class Grid(c: Context, val cols: Int, val rows: Int) : ViewGroup(c) {
    var lastX = 0f
    var lastY = 0f

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val h = MeasureSpec.getSize(hSpec)
        setMeasuredDimension(w, h)
        val cw = (w - paddingLeft - paddingRight) / cols
        val ch = (h - paddingTop - paddingBottom) / rows
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val m = v.tag as? Item
            if (m != null) {
                v.measure(
                    MeasureSpec.makeMeasureSpec(cw * m.w, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(ch * m.h, MeasureSpec.EXACTLY)
                )
            } else {
                v.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
            }
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        val h = b - t
        val cw = (w - paddingLeft - paddingRight) / cols
        val ch = (h - paddingTop - paddingBottom) / rows
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val m = v.tag as? Item
            if (m != null) {
                val x = paddingLeft + (m.cell % cols) * cw
                val y = paddingTop + (m.cell / cols) * ch
                v.layout(x, y, x + cw * m.w, y + ch * m.h)
            } else {
                v.layout(0, 0, w, h)
            }
        }
    }

    fun cellAt(x: Float, y: Float): Int {
        val cw = ((width - paddingLeft - paddingRight) / cols).coerceAtLeast(1)
        val ch = ((height - paddingTop - paddingBottom) / rows).coerceAtLeast(1)
        val col = ((x - paddingLeft) / cw).toInt().coerceIn(0, cols - 1)
        val row = ((y - paddingTop) / ch).toInt().coerceIn(0, rows - 1)
        return row * cols + col
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            lastX = e.x
            lastY = e.y
        }
        return super.onTouchEvent(e)
    }
}

/** Контейнер виджета: ловит долгое нажатие, не мешая самому виджету; сообщает виджету его размер. */
class LongFrame(c: Context, val onLong: (View) -> Unit) : FrameLayout(c) {
    private val lp = Runnable { onLong(this) }
    private var sx = 0f
    private var sy = 0f

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sx = e.x
                sy = e.y
                postDelayed(lp, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> if (Math.abs(e.x - sx) > 24 || Math.abs(e.y - sy) > 24) removeCallbacks(lp)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> removeCallbacks(lp)
        }
        return super.dispatchTouchEvent(e)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val d = resources.displayMetrics.density
        val wd = (w / d).toInt()
        val hd = (h / d).toInt()
        (getChildAt(0) as? AppWidgetHostView)?.updateAppWidgetSize(Bundle(), wd, hd, wd, hd)
    }
}

/**
 * Режим «растягивания»: рамка вокруг элемента с ручками в левом верхнем и правом нижнем углу.
 * Тянете ручку — рамка привязывается к ячейкам. Касание вне рамки — готово.
 */
class ResizeOverlay(
    c: Context,
    private val cols: Int, private val rows: Int,
    private var x: Int, private var y: Int, private var w: Int, private var h: Int,
    private val padL: Int, private val padT: Int, private val padR: Int, private val padB: Int,
    private val acc: Int,
    private val ok: (Int, Int, Int, Int) -> Boolean,
    private val commit: (Int, Int, Int, Int) -> Unit,
    private val done: () -> Unit
) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = c.resources.displayMetrics.density
    private var mode = 0 // 0 — ничего, 1 — правый нижний угол, 2 — левый верхний

    private fun cw() = (width - padL - padR) / cols.toFloat()
    private fun ch() = (height - padT - padB) / rows.toFloat()

    override fun onDraw(c: Canvas) {
        val l = padL + x * cw()
        val t = padT + y * ch()
        val r = l + w * cw()
        val b = t + h * ch()
        p.style = Paint.Style.FILL
        p.color = (acc and 0xFFFFFF) or 0x33000000
        c.drawRect(l, t, r, b, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3 * d
        p.color = acc
        c.drawRect(l, t, r, b, p)
        p.style = Paint.Style.FILL
        c.drawCircle(r, b, 11 * d, p)
        c.drawCircle(l, t, 11 * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cw = cw()
        val ch = ch()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val l = padL + x * cw
                val t = padT + y * ch
                val r = l + w * cw
                val b = t + h * ch
                val s = 36 * d
                mode = if (Math.hypot((e.x - r).toDouble(), (e.y - b).toDouble()) < s) 1
                else if (Math.hypot((e.x - l).toDouble(), (e.y - t).toDouble()) < s) 2
                else if (e.x in l..r && e.y in t..b) 0
                else -1
                if (mode == -1) {
                    mode = 0
                    done()
                }
            }
            MotionEvent.ACTION_MOVE -> if (mode > 0) {
                val fx = ((e.x - padL) / cw).toInt().coerceIn(0, cols - 1)
                val fy = ((e.y - padT) / ch).toInt().coerceIn(0, rows - 1)
                var nx = x
                var ny = y
                var nw = w
                var nh = h
                if (mode == 1) {
                    nw = (fx - x + 1).coerceAtLeast(1)
                    nh = (fy - y + 1).coerceAtLeast(1)
                } else {
                    val rx = x + w
                    val ry = y + h
                    nx = fx.coerceAtMost(rx - 1)
                    ny = fy.coerceAtMost(ry - 1)
                    nw = rx - nx
                    nh = ry - ny
                }
                if (nx + nw <= cols && ny + nh <= rows && (nx != x || ny != y || nw != w || nh != h) && ok(nx, ny, nw, nh)) {
                    x = nx
                    y = ny
                    w = nw
                    h = nh
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> if (mode > 0) {
                mode = 0
                commit(x, y, w, h)
            }
        }
        return true
    }
}
