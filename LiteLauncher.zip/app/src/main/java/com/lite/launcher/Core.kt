package com.lite.launcher

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.AdaptiveIconDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.concurrent.Executors

fun Context.dp(v: Number): Int = (v.toFloat() * resources.displayMetrics.density + 0.5f).toInt()

class AppInfo(val pkg: String, val cls: String, val label: String) {
    fun name(): String = P.name(pkg) ?: label
}

class Item(val pkg: String, var page: Int, var cell: Int, var w: Int = 1, var h: Int = 1) {
    val isFolder: Boolean get() = pkg.startsWith("folder:")
    val isWidget: Boolean get() = pkg.startsWith("widget:")
    val isApp: Boolean get() = !isFolder && !isWidget
    val id: Int get() = pkg.substringAfter(':').toIntOrNull() ?: 0
}

/** Геометрия сетки: пересечения и поиск свободного места. */
object Lay {
    fun overlaps(its: List<Item>, page: Int, x: Int, y: Int, w: Int, h: Int, cols: Int, ex: Item?): Item? {
        for (o in its) {
            if (o === ex || o.page != page) continue
            val ox = o.cell % cols
            val oy = o.cell / cols
            if (x < ox + o.w && ox < x + w && y < oy + o.h && oy < y + h) return o
        }
        return null
    }
}

/** Все настройки + значения по умолчанию в одном месте. */
object P {
    private lateinit var sp: SharedPreferences
    lateinit var usage: SharedPreferences
    private var ready = false

    val def: Map<String, Any> = mapOf(
        // рабочий стол
        "cols" to 4, "rows" to 5, "pages" to 3, "infinite" to true, "lock" to false, "align" to false,
        "edge" to 8, "gap" to 4, "dots" to true, "dotSize" to 7,
        "clock" to true, "date" to true, "clockSp" to 52,
        // иконки
        "iconDp" to 52, "labelSp" to 11, "showLabels" to true, "lines" to 1, "shadow" to true,
        "homeText" to "white", "shape" to "squircle", "mono" to false, "scale" to 100,
        // док
        "dockShow" to true, "dockN" to 4, "dockIcon" to 48, "dockLabels" to false,
        "dockAlpha" to 45, "dockRadius" to 28, "dockMargin" to 10,
        // меню приложений
        "dCols" to 4, "dList" to false, "dIcon" to 48, "dSort" to "alpha", "search" to "top",
        "autoKb" to false, "dAlpha" to 92,
        // внешний вид
        "theme" to "system", "accent" to 0xFF4C9AFF.toInt(), "accWall" to false,
        "hideStatus" to false, "hideNav" to false,
        // анимации / экономия
        "lite" to false, "anim" to true, "animType" to "slide", "pageFx" to "slide",
        "launchAnim" to "zoom", "animMs" to 220, "animAuto" to true,
        // жесты
        "gUp" to "drawer", "gDown" to "notif", "gDouble" to "none", "gLong" to "menu", "gHome" to "reset",
        // данные
        "hidden" to "", "home" to "", "dock" to "", "init" to false
    )

    fun init(c: Context) {
        if (ready) return
        val a = c.applicationContext
        sp = a.getSharedPreferences("s", Context.MODE_PRIVATE)
        usage = a.getSharedPreferences("u", Context.MODE_PRIVATE)
        ready = true
    }

    fun i(k: String): Int = sp.getInt(k, def[k] as Int)
    fun b(k: String): Boolean = sp.getBoolean(k, def[k] as Boolean)
    fun s(k: String): String = sp.getString(k, def[k] as String) ?: ""
    fun rev(): Int = sp.getInt("rev", 0)

    fun put(k: String, v: Any) {
        val e = sp.edit()
        when (v) {
            is Boolean -> e.putBoolean(k, v)
            is Int -> e.putInt(k, v)
            is String -> e.putString(k, v)
        }
        e.putInt("rev", rev() + 1).apply()
    }

    // переименование
    fun name(pkg: String): String? = sp.getString("n_$pkg", null)
    fun setName(pkg: String, n: String) {
        val e = sp.edit()
        if (n.isBlank()) e.remove("n_$pkg") else e.putString("n_$pkg", n.trim())
        e.putInt("rev", rev() + 1).apply()
    }

    // скрытые
    fun hidden(): MutableSet<String> = s("hidden").split('\n').filter { it.isNotEmpty() }.toMutableSet()

    // раскладка
    fun items(): MutableList<Item> = s("home").split('\n').mapNotNull {
        val p = it.split('|')
        if (p.size >= 3) Item(
            p[0], p[1].toIntOrNull() ?: 0, p[2].toIntOrNull() ?: 0,
            (p.getOrNull(3)?.toIntOrNull() ?: 1).coerceAtLeast(1), (p.getOrNull(4)?.toIntOrNull() ?: 1).coerceAtLeast(1)
        ) else null
    }.toMutableList()

    fun saveItems(l: List<Item>) = put("home", l.joinToString("\n") { "${it.pkg}|${it.page}|${it.cell}|${it.w}|${it.h}" })

    // папки: первая строка — название, дальше пакеты приложений
    fun folder(id: Int): Pair<String, MutableList<String>> {
        val l = (sp.getString("f_$id", "") ?: "").split('\n')
        return Pair(l.firstOrNull() ?: "", l.drop(1).filter { it.isNotEmpty() }.toMutableList())
    }

    fun saveFolder(id: Int, name: String, apps: List<String>) {
        val t = (listOf(name.replace('\n', ' ')) + apps).joinToString("\n")
        sp.edit().putString("f_$id", t).putInt("rev", rev() + 1).apply()
    }

    fun deleteFolder(id: Int) {
        sp.edit().remove("f_$id").putInt("rev", rev() + 1).apply()
    }
    fun dock(): MutableList<String> = s("dock").split('\n').filter { it.isNotEmpty() }.toMutableList()
    fun saveDock(l: List<String>) = put("dock", l.joinToString("\n"))

    // статистика запусков
    fun bump(pkg: String) {
        usage.edit().putInt("c_$pkg", usage.getInt("c_$pkg", 0) + 1)
            .putLong("t_$pkg", System.currentTimeMillis()).apply()
    }

    // резервная копия
    fun export(): String {
        val o = JSONObject()
        for ((k, v) in sp.all) o.put(k, v)
        return o.toString(1)
    }

    fun import(t: String) {
        val o = JSONObject(t)
        val e = sp.edit()
        e.clear()
        for (k in o.keys()) {
            when (val v = o.get(k)) {
                is Boolean -> e.putBoolean(k, v)
                is Int -> e.putInt(k, v)
                is Long -> e.putInt(k, v.toInt())
                is String -> e.putString(k, v)
            }
        }
        e.apply()
        put("imported", true)
    }

    fun reset() {
        val r = rev() + 1
        sp.edit().clear().putInt("rev", r).apply()
        usage.edit().clear().apply()
    }
}

/** Цвета и тема. */
object Th {
    fun dark(c: Context): Boolean = when (P.s("theme")) {
        "dark" -> true
        "light" -> false
        "time" -> {
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            h < 7 || h >= 19
        }
        else -> (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    fun bg(c: Context): Int = if (dark(c)) Color.rgb(18, 22, 28) else Color.rgb(242, 244, 247)
    fun text(c: Context): Int = if (dark(c)) Color.rgb(236, 239, 241) else Color.rgb(27, 31, 35)
    fun withAlpha(c: Int, pct: Int): Int = (c and 0xFFFFFF) or ((pct.coerceIn(0, 100) * 255 / 100) shl 24)

    fun accent(c: Context): Int {
        if (P.b("accWall") && Build.VERSION.SDK_INT >= 27) {
            try {
                val w = WallpaperManager.getInstance(c).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                if (w != null) return w.primaryColor.toArgb()
            } catch (_: Throwable) {
            }
        }
        return P.i("accent")
    }
}

/** Список приложений: сначала мгновенно из кэша, потом тихо обновляется в фоне. */
object Apps {
    @Volatile
    var list: List<AppInfo> = emptyList()

    fun loadCache(c: Context) {
        if (list.isNotEmpty()) return
        try {
            val f = File(c.applicationContext.filesDir, "apps.txt")
            if (f.exists()) {
                list = f.readLines().mapNotNull {
                    val p = it.split('\t')
                    if (p.size == 3) AppInfo(p[0], p[1], p[2]) else null
                }
            }
        } catch (_: Throwable) {
        }
    }

    fun refresh(c: Context, done: (Boolean) -> Unit) {
        val app = c.applicationContext
        Thread {
            var changed = false
            try {
                val pm = app.packageManager
                val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val old = list.associateBy { it.pkg + "/" + it.cls }
                val l = pm.queryIntentActivities(i, 0).map { r ->
                    val k = r.activityInfo.packageName + "/" + r.activityInfo.name
                    old[k] ?: AppInfo(r.activityInfo.packageName, r.activityInfo.name, r.loadLabel(pm).toString())
                }.sortedBy { it.label.lowercase() }
                changed = l.size != old.size || l.any { (it.pkg + "/" + it.cls) !in old }
                if (changed) {
                    list = l
                    File(app.filesDir, "apps.txt").writeText(l.joinToString("\n") { "${it.pkg}\t${it.cls}\t${it.label}" })
                }
            } catch (_: Throwable) {
            }
            Handler(Looper.getMainLooper()).post { done(changed) }
        }.start()
    }

    fun find(pkg: String): AppInfo? = list.firstOrNull { it.pkg == pkg }
}

/** Кэш иконок: ограничен по байтам, грузится лениво в одном фоновом потоке. */
object Icons {
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 12).coerceIn(2L * 1024 * 1024, 16L * 1024 * 1024).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val ex = Executors.newSingleThreadExecutor()
    private val h = Handler(Looper.getMainLooper())
    private val waiting = HashMap<String, MutableList<ImageView>>()

    fun bind(iv: ImageView, a: AppInfo) {
        iv.tag = a.pkg
        val b = cache.get(a.pkg)
        if (b != null) {
            iv.setImageBitmap(b)
            return
        }
        iv.setImageDrawable(null)
        val l = waiting[a.pkg]
        if (l != null) {
            l.add(iv)
            return
        }
        waiting[a.pkg] = mutableListOf(iv)
        val ctx = iv.context.applicationContext
        ex.execute {
            val bmp = render(ctx, a)
            h.post {
                if (bmp != null) cache.put(a.pkg, bmp)
                waiting.remove(a.pkg)?.forEach { if (it.tag == a.pkg && bmp != null) it.setImageBitmap(bmp) }
            }
        }
    }

    fun clear() {
        cache.evictAll()
    }

    private fun render(c: Context, a: AppInfo): Bitmap? = try {
        val px = (64 * c.resources.displayMetrics.density).toInt()
        val d = c.packageManager.getActivityIcon(ComponentName(a.pkg, a.cls))
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            // рисуем слои без маски, форму задаёт IconView (круг/сквиркл/квадрат)
            val big = (px * 1.5f).toInt()
            val o = (px - big) / 2
            d.background?.let { it.setBounds(o, o, o + big, o + big); it.draw(cv) }
            d.foreground?.let { it.setBounds(o, o, o + big, o + big); it.draw(cv) }
        } else {
            d.setBounds(0, 0, px, px)
            d.draw(cv)
        }
        bmp
    } catch (_: Throwable) {
        null
    }
}
